--
-- Database: `skill`
--

-- --------------------------------------------------------

--
-- Table structure for table `info`
--

CREATE TABLE `info` (
  `id` int(11) NOT NULL,
  `name` text NOT NULL,
  `skill` varchar(100) NOT NULL,
  `photo` varchar(100) NOT NULL,
  `det` varchar(1000) NOT NULL,
  `pica` varchar(100) NOT NULL,
  `picb` varchar(100) NOT NULL,
  `picc` varchar(100) NOT NULL,
  `area` varchar(100) NOT NULL,
  `phone` varchar(100) NOT NULL,
  `email` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `info`
--

INSERT INTO `info` (`id`, `name`, `skill`, `photo`, `det`, `pica`, `picb`, `picc`, `area`, `phone`, `email`) VALUES
(1, 'isfdyg', 'sdljhlig', 'Captukhbvre.PNG', 'sd,jfgvb', 'Captukhbvre.PNG', 'Captukhbvre.PNG', 'Captukhbvre.PNG', 'sdj', 'sdfvb', 'sjfgv'),
(2, 'isfdyg', 'sdljhlig', 'Captukhbvre.PNG', 'sd,jfgvb', 'Captukhbvre.PNG', 'Captukhbvre.PNG', 'Captukhbvre.PNG', 'sdj', 'sdfvb', 'sjfgv'),
(3, 'est5y', 'eyd', 'Captukhbvre.PNG', 'erya', 'Captukhbvre.PNG', 'Captukhbvre.PNG', 'Captukhbvre.PNG', 'ERY', 'ERY', 'ERY');

-- --------------------------------------------------------

--
-- Table structure for table `information`
--

CREATE TABLE `information` (
  `id` int(11) NOT NULL,
  `sign_id` int(11) NOT NULL,
  `profilepic` text,
  `detail` text,
  `demopic1` text,
  `demopic2` text,
  `place` text,
  `phone` int(12) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `post`
--

CREATE TABLE `post` (
  `id` int(100) NOT NULL,
  `post` varchar(1000) NOT NULL,
  `name` varchar(100) NOT NULL,
  `type` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `post`
--

INSERT INTO `post` (`id`, `post`, `name`, `type`) VALUES
(12, 'ashik', 'shafayet', '19'),
(13, 'ashik', 'shafayet', '19'),
(14, 'saf', 'sfh', 'kieyfgr'),
(15, 'saf', 'sfh', 'kieyfgr');

-- --------------------------------------------------------

--
-- Table structure for table `signin`
--

CREATE TABLE `signin` (
  `id` int(100) NOT NULL,
  `name` text NOT NULL,
  `email` varchar(100) NOT NULL,
  `pass` varchar(100) NOT NULL,
  `repass` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `signin`
--

INSERT INTO `signin` (`id`, `name`, `email`, `pass`, `repass`) VALUES
(1, 'liton', 'saiful.sust.cse@gmail.com', 'aa', 'aa'),
(2, 'liton', 'saiful.sust.cse@gmail.com', 'aa', 'aa'),
(3, 'ashik', 'ashik.shafayet.19aug@gmail.com', 'aa', 'aa'),
(4, 'ashik', 'ashik.shafayet.19aug@gmail.com', 'aa', 'aa'),
(5, 'ashik', 'ashik.shafayet.19aug@gmail.com', 'aa', 'aa'),
(6, 'ashik', 'ashik.shafayet.19aug@gmail.com', 'aa', 'aa'),
(7, 'ashik', 'ashik.shafayet.19aug@gmail.com', 'aa', 'aa'),
(8, 'ashik', 'ashik.shafayet.19aug@gmail.com', 'aa', 'aa'),
(9, 'ashik', 'ashik.shafayet.19aug@gmail.com', 'aa', 'aa'),
(10, 'liton', 'saiful.sust.cse@gmail.com', 'aa', 'aa'),
(11, 'liton', 'saiful.sust.cse@gmail.com', 'aa', 'aa'),
(12, 'liton', 'saiful.sust.cse@gmail.com', 'aa', 'aa'),
(13, 'liton', 'saiful.sust.cse@gmail.com', 'aa', 'aa'),
(14, 'liton', 'saiful.sust.cse@gmail.com', 'aa', 'aa'),
(15, 'liton', 'saiful.sust.cse@gmail.com', 'aa', 'aa'),
(16, 'liton', 'saiful.sust.cse@gmail.com', 'aa', 'aa'),
(17, 'liton', 'saiful.sust.cse@gmail.com', 'aa', 'aa'),
(18, 'ashik', 'ashik.shafayet.19aug@gmail.com', 'aaa', 'aa');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `info`
--
ALTER TABLE `info`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `information`
--
ALTER TABLE `information`
  ADD PRIMARY KEY (`id`),
  ADD KEY `sign_id` (`sign_id`);

--
-- Indexes for table `post`
--
ALTER TABLE `post`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `signin`
--
ALTER TABLE `signin`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `info`
--
ALTER TABLE `info`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;
--
-- AUTO_INCREMENT for table `information`
--
ALTER TABLE `information`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `post`
--
ALTER TABLE `post`
  MODIFY `id` int(100) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=16;
--
-- AUTO_INCREMENT for table `signin`
--
ALTER TABLE `signin`
  MODIFY `id` int(100) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=19;
--
-- Constraints for dumped tables
--

--
-- Constraints for table `information`
--
ALTER TABLE `information`
  ADD CONSTRAINT `information_ibfk_1` FOREIGN KEY (`sign_id`) REFERENCES `signin` (`id`);

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
